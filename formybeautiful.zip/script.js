// ... existing code ...

// Get the love button
const loveButton = document.querySelector('.lovein');

// Add click event listener to the love button
loveButton.addEventListener('click', (lovein) => {
    audio.play(your_love_song.mp);
});

// ... rest of your code ...